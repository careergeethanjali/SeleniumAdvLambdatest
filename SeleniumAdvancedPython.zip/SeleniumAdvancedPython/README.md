# pythonSeleniumAdvancedTest
pythonSeleniumAdvanced Lambda Test Certification

Added the code used for attempting the subjective assessment of selenium advanced using python.
Successfully executed the code in Lambda test environment. Test Ids for Test Scenarios

UEPVN-BYKBF-WVLYN-8EGBH - Using Google Chrome

TZBOG-W5B8E-IIM5W-KZXIM - Using Microsoft edge
main
